<cc-element cc-id="style">
    <link data-src="stylesheet-bootstrap" href="{base_element}package/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link data-src="stylesheet-freelancer" href="{base_element}package/css/freelancer.min.css" rel="stylesheet">
    <link data-src="stylesheet-font-awesome" href="{base_element}package/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link data-src="stylesheet-bootstrap" href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link data-src="stylesheet-bootstrap" href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <style type="text/css">
    .footer-col  li {
      display: inline !important;
    }
    </style>
</cc-element>

<cc-element cc-id="content">
    <footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col col-md-4">
                        <h3>Location</h3>
                        <p>3481 Bali
                            <br>Sanur, CA 90210</p>
                    </div>
                    <div class="footer-col col-md-4">
                        <h3>Around the Web</h3>
                        <ul class="list-inline">
                            <li>
                                <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                            </li>
                            <li>
                                <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
                            </li>
                            <li>
                                <a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-col col-md-4">
                        <h3>About Cicool</h3>
                        <p>Cicool is a web builder, for creating web dinamic in one times created by <a href="ridwans.com">Ridwanskaterock</a>.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; Your Website 2016
                    </div>
                </div>
            </div>
        </div>
    </footer>
</cc-element>


<cc-element cc-id="script" cc-placement="top">
    <script src="{base_element}package/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="{base_element}package/js/jqBootstrapValidation.js"></script>
    <script src="{base_element}package/js/contact_me.js"></script>
    <script src="{base_element}package/js/freelancer.min.js"></script>
    <script type="text/javascript">
    </script>
</cc-element>