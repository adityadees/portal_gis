
<cc-element cc-id="style">
  
</cc-element>

<cc-element cc-id="content">
  <div class="container">
    <div class="row">
       <div class="column col-md-12">
        <h1>The Heading</h1>
        <p>Cicool is, an engine builder that provides tools to facilitate you in building a dynamic website, very easy to use, easy also to costume with dynamic content.</p>
       </div>
    </div>
  </div>
</cc-element>


<cc-element cc-id="script" cc-placement="top">
   
</cc-element>