
<cc-element cc-id="style">
  
</cc-element>

<cc-element cc-id="content">
  <div class="container">
    <div class="row">
       <div class="column col-md-6">
        <h1>The Heading</h1>
        <p>Cicool is, an engine builder that provides tools to facilitate you in building a dynamic website, very easy to use, easy also to costume with dynamic content.</p>
       </div>
       <div class="column col-md-6">
        <p>Whether you're a student looking to showcase your work, a professional looking to attract clients, or a graphic artist looking to share your projects, this template is the perfect starting point!</p>
       </div>
    </div>
  </div>
</cc-element>


<cc-element cc-id="script" cc-placement="top">
   
</cc-element>