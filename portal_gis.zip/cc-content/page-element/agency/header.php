<cc-element cc-id="style">
    <link href="{base_element}package/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="{base_element}package/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
    <link href="{base_element}package/css/agency.min.css" rel="stylesheet">
</cc-element>

<cc-element cc-id="content">
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">Welcome To Cicool!</div>
                <div class="intro-heading">It's Nice To Meet You</div>
                <a href="#services" class="page-scroll btn btn-xl">Tell Me More</a>
            </div>
        </div>
    </header>
</cc-element>

<cc-element cc-id="script" cc-placement="top">
    <script src="{base_element}package/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="{base_element}package/https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="{base_element}package/js/jqBootstrapValidation.js"></script>
    <script src="{base_element}package/js/contact_me.js"></script>
    <script src="{base_element}package/js/agency.min.js"></script>
</cc-element>