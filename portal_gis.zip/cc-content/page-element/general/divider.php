<cc-element cc-id="style">
    <link href="{base_element}package/css/general.css" rel="stylesheet">
</cc-element>

<cc-element cc-id="content">
    <div class="col-md-12">
        <hr class="shadowDown">
    </div>
</cc-element>
