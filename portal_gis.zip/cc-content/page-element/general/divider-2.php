<cc-element cc-id="style">
    <link href="{base_element}package/css/general.css" rel="stylesheet">
</cc-element>

<cc-element cc-id="content">
    <div class="wrapperDark">
            <div class="container">
                <div class="col-md-12">
                    <div class="divider dashed">
                        <span>READ MORE BELOW</span>
                    </div>
                </div>
            </div>
        </div>
</cc-element>
