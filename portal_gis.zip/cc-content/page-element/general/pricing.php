<cc-element cc-id="style">
    <link href="{base_element}package/css/general.css" rel="stylesheet">
</cc-element>

<cc-element cc-id="content">
    <div class="columns">
      <ul class="price">
        <li class="header">Basic</li>
        <li class="grey">$ 9.99 / year</li>
        <li>10GB Storage</li>
        <li>10 Emails</li>
        <li>10 Domains</li>
        <li>1GB Bandwidth</li>
        <li class="grey"><a href="#" class="button">Sign Up</a></li>
      </ul>
    </div> 
    <div class="columns">
      <ul class="price">
        <li class="header">Premium</li>
        <li class="grey">$ 30.99 / year</li>
        <li>1000GB Storage</li>
        <li>Unlimited Emails</li>
        <li>Unlimited Domains</li>
        <li>100GB Bandwidth</li>
        <li class="grey"><a href="#" class="button">Sign Up</a></li>
      </ul>
    </div>
     <div class="columns">
      <ul class="price">
        <li class="header">Buisness</li>
        <li class="grey">$ 50.33 / year</li>
        <li>Unlimited Storage</li>
        <li>Unlimited Emails</li>
        <li>Unlimited Domains</li>
        <li>Unlimited Bandwidth</li>
        <li class="grey"><a href="#" class="button">Sign Up</a></li>
      </ul>
    </div>
</cc-element>

<cc-element cc-id="script" cc-placement="top">
  
</cc-element>