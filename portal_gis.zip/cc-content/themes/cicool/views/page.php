<?= get_header(); ?>

<body id="page-top" style="margin-top: 50px;">

    <?= get_navigation(); ?>

    <?= $page->content; ?>

<?= get_footer(); ?>
