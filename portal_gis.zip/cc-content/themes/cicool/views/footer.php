
    <!-- jQuery -->
   
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= theme_asset(); ?>/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?= theme_asset(); ?>/vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="<?= theme_asset(); ?>/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="<?= theme_asset(); ?>/js/creative.min.js"></script>

</body>

</html>
