<?= get_header(); ?>
<body id="page-top">
   <?= get_navigation(); ?>

     <header>
      <div class="header-content" >
         <div class="header-content-inner">
            <h1 id="homeHeading">Thanks for buying cicool builder</h1>
            <hr>
            <p> you can customize this page by editing this on location <br><code><?=  './cc-content/themes/cicool/view/home.php' ?> </code></p>
            <a href="https://github.com/ridwanskaterock/cicool/issues" class="btn btn-primary btn-xl page-scroll" target="blank"><i class="fa fa-github"></i> Support</a>
         </div>
      </div>
   </header>
   <?= get_footer(); ?>