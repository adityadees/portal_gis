<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<title>404 Page Not Found</title>
<meta charset="utf-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>Page Not Found</title>
<link href="<?= theme_asset(); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
	.container {
		margin-top: 10%;
	}
</style>
</head>
<body>
    <div class="container text-center">
    	<p><img src="<?= theme_asset(); ?>/img/404.png"></p>
        <h2 class="text-muted">Page Not Found</h2>
    </div>
</body>
</html>