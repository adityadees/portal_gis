<?php 

/*define base extension*/
$base_url_extension = url_extension(basename(__DIR__)); 
$base_url_extension_medium = BASE_ASSET . 'editor/src/js/extensions'; 

/*register script file*/
//$cc_core->cc_html->registerScriptFile( $base_url_extension.'/medium-button.js');
//$cc_core->cc_html->registerScriptFile( $base_url_extension.'/cicool.js');



?>