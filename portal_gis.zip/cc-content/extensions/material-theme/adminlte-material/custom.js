$.material.init();

$(function(){
});