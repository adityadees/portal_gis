# meterial-themes
material themes for cicool extension

download and copying folder to your cicool apps

copy to folder `your-cicool-app/cc-content/extension/`

template by : <a href='https://github.com/DucThanhNguyen/MaterialAdminLTE'>MaterialAdminLTE</a>
