<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Base Site URL
|--------------------------------------------------------------------------
|
| Config id and secret for oauth,
|
*/

$config['google'] = [
	'id' => '929398370510-i83slop9palnf68hee8iles7jqmkh7gr.apps.googleusercontent.com',
	'secret' => 'dQs4CxZMBN4nRMj-UzFyn0Ci'
];